require("babel-core/register");
require("./test.js");